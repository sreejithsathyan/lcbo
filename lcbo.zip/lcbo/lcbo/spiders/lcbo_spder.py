# -*- coding: utf-8 -*-
import scrapy
from scrapy.http import Request
import re

class LcboSpderSpider(scrapy.Spider):
	name = 'lcbo_spder'
	# allowed_domains = ['https://www.lcbo.com/']
	start_urls = ['https://www.lcbo.com/webapp/wcs/stores/servlet/en/lcbo/beer-cider-16?pageView=grid&orderBy=5&beginIndex=0']

	def parse(self, response):
		productUrls = response.xpath('//div[@class="product_name"]/a/@href').extract()
		next_page = response.xpath('//a[@class="right_arrow"]/@href').extract_first()
		print('Success request to product page',next_page)
		for url in productUrls:
			yield scrapy.Request(url=url, callback=self.parse_product,dont_filter=True)
		if next_page:
			yield scrapy.Request(url=next_page, callback=self.parse)


	def parse_product(self, response):
		name= ''
		price= ''
		ml= ''
		lcbo= ''
		productDes= ''
		print('Success request to product page')
		name = response.xpath('//h1[@class="main_header"]/text()').extract_first()
		price = response.xpath('//span[@class="price"]/text()').extract_first()
		productQuantity = response.xpath('//small[@id="prodSku"]/span/text()').extract()
		productDes = response.xpath('//div[@class="product-text-content"]/p/text()').extract_first()

		#extract data
		if name:
			name = name.strip()
		if price:
			price = price.strip()
		if productQuantity:
			ml = productQuantity[0].strip()
			lcbo = productQuantity[1].strip()
			lcbo = re.findall(r'\b\d+\b',lcbo)[0]
		if productDes:
			productDes = productDes.strip()

		data = {
			'name' : name,
			'price' : price,
			'ml' : ml,
			'lcbo': lcbo,
			'productDes' : productDes,
		}
		print(data)
		yield data

